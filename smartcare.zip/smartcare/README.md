# SmartCare HTML/CSS/JavaScript conversion

This is a framework-free static conversion/prototype of the SmartCare dental clinic UI.

## Run it
- Open `index.html` directly in a browser, or
- From this folder run `python -m http.server 8000` and visit `http://localhost:8000`.

## Included
- Responsive public landing page (services, how it works, doctor profile)
- Demo role selection/login (Patient, Clerk, Dentist, Admin)
- Role-based sidebar navigation and converted page layouts
- Demo patient booking and intake forms
- Local browser storage for demo session/request only

## Important limitations
This is a UI conversion, not a migration of a live backend. The original app's server/auth/database integrations are not connected. Booking and intake forms only demonstrate interactions locally; they do not create real appointments or patient records. Several original dashboard routes were placeholders in the source app and remain informational placeholders here.

## Structure
- `index.html` — document shell
- `css/style.css` — responsive styles and theme tokens
- `js/script.js` — navigation, demo login, and UI interactions
- `assets/` — project image assets
