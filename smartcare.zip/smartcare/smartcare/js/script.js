const view = document.getElementById("view");
const app = document.getElementById("app");
document.getElementById("year").textContent = new Date().getFullYear();
const users = {
  patient:{name:"",title:"Patient",pid:"",home:"/patient/book"},
  admin:{name:"Admin",title:"Clinic Practice Director",home:"/admin",username:"Admin",password:"Admin123"}
};
const roleMeta = {
 patient:{label:"Patient",icon:"♙",desc:"Book visits, view appointments, and track the live queue."},
 admin:{label:"Admin",icon:"⬡",desc:"Analytics, triage, operatory schedule, and directory."}
};
const navs = {
 patient:[["/patient/book","▦","Book Appointment"],["/patient/appointments","▤","My Appointments"]],
 admin:[["/admin/triage","⌁","Live Queue & Triage"],["/admin/schedule","▦","Operatory Schedule"],["/admin/workspace","✚","Chairside Clinical Workspace"],["/admin","▥","Admin Analytics & Capacity"]]
};
function logo(subtitle="Dental Clinic"){return `<a class="brand" href="#/"><span class="brand-mark" aria-hidden="true">✦</span><span class="brand-copy"><strong>SmartCare</strong><small>${subtitle}</small></span></a>`}
function landing(){return `
<section class="hero"><div class="container hero-grid"><div>
 <div class="eyebrow">A better dental visit starts here</div>
 <h1>Book your dental visit. Skip the waiting</h1>
 <p class="hero-copy">Reserve a time, get a queue number, and watch your place in line live. Arrive when it is nearly your turn.</p>
 <div class="hero-actions"><a class="button button-primary" href="#/login?audience=patient">Book an Appointment <span aria-hidden="true">→</span></a><a class="button button-outline" href="#how-it-works">How it works</a></div>
 <div class="hero-note"><span class="checkmark">✓</span> No online payment required · Pay at the clinic after your visit</div>
 </div><div class="hero-art" aria-label="Dental care illustration"><div class="tooth-illustration"></div><div class="floating-card float-one"><span class="float-icon">✓</span><span><strong>Care made simple</strong><small>Easy online booking</small></span></div><div class="floating-card float-two"><span class="float-icon">◷</span><span><strong>Track your queue</strong><small>Know when it's your turn</small></span></div></div></div></section>
<section class="section section-tint"><div class="container"><div class="section-heading"><h2>World-Class Dental Care &amp; Modern Comfort Technology</h2><p>Thoughtful care, a calm environment, and a smoother way to plan your visit.</p></div><div class="feature-grid">
 <article class="feature-card"><div class="icon-box">⌂</div><h3>Discover Your Best Smile</h3><p>Track your smile progress and take a confident step toward better oral health.</p></article>
 <article class="feature-card"><div class="icon-box">✧</div><h3>Safe and Super Clean Tools</h3><p>Every tool goes through a thorough cleaning process, and fresh, safe tools are opened just for you, every time.</p></article>
 <article class="feature-card"><div class="icon-box">▱</div><h3>Cozy Rooms, Peaceful Care</h3><p>Relax in our comfortable chairs and enjoy a quiet, clean, calm space where we take care of you gently.</p></article>
 </div></div></section>
<section class="section" id="services"><div class="container"><div class="section-heading"><div class="eyebrow">Our services</div><h2>Care that fits your smile</h2><p>Explore common treatments and get a clearer idea of what your visit may include.</p></div><div class="service-grid">
 <article class="service-card"><span class="tag">Routine Care</span><h3>Oral Prophylaxis &amp; Cleaning</h3><p>Includes ultrasonic removal of mineralized deposits and surface stains, followed by a professional polish.</p><div class="price-row"><div><div class="price">₱1,500</div><div class="service-sub">Standard appointment (~45 min)</div></div></div></article>
 <article class="service-card"><span class="tag tag-purple">Restorative</span><h3>Durable Esthetic Dental Restorations</h3><p>Shade-matched, light-cured composite bonding to repair decay or defects while preserving healthy structure.</p><div class="price-row"><div><div class="price">₱1,800 <span class="price-note">/tooth</span></div><div class="service-sub">High-grade composite material</div></div></div></article>
 <article class="service-card"><span class="tag">Surgery</span><h3>Tooth Extraction (Routine/Surg)</h3><p>Careful tooth removal prioritized to minimize tissue damage, with specialized local anesthesia delivery.</p><div class="price-row"><div><div class="price">₱2,000+</div><div class="service-sub">Price varies with complexity</div></div></div></article>
 <article class="service-card"><span class="tag">Orthodontics</span><h3>Orthodontics &amp; Clear Braces</h3><p>Assessment of bite and alignment with advanced 3D scanning technology and digital analysis.</p><div class="price-row"><div><div class="price">₱1,200 <span class="price-note">consult</span></div><div class="service-sub">Includes 3D intraoral scan report</div></div></div></article>
 </div></div></section>
<section class="section section-tint" id="how-it-works"><div class="container"><div class="section-heading"><div class="eyebrow">Simple by design</div><h2>Your appointment in four easy steps</h2><p>From choosing a service to arriving at the clinic, we help make every step straightforward.</p></div><div class="steps-grid">
 <article class="step-card"><span class="step-number">01 / STEP</span><div class="icon-box">✧</div><h3>Select Service</h3><p>Browse routine cleanings, tooth-colored fillings, tooth removals, or brace consultations.</p></article>
 <article class="step-card"><span class="step-number">02 / STEP</span><div class="icon-box">♙</div><h3>Choose Dentist</h3><p>Select your preferred dentist based on their background and expertise.</p></article>
 <article class="step-card"><span class="step-number">03 / STEP</span><div class="icon-box">▦</div><h3>Pick Date &amp; Time Slot</h3><p>Pick a convenient day and time with schedule availability.</p></article>
 <article class="step-card"><span class="step-number">04 / STEP</span><div class="icon-box">✓</div><h3>Arrive for Easy Care</h3><p>Check in and enjoy treatment in a clean room with less waiting-room hassle.</p></article>
 </div></div></section>
<section class="section" id="doctors"><div class="container doctor-wrap"><div><div class="eyebrow">Meet your care team</div><h2 style="font-size:34px">Experienced hands. Thoughtful care.</h2><p style="color:var(--muted);margin-top:14px;line-height:1.8">Get to know the people helping you care for your smile, one visit at a time.</p></div><article class="doctor-card"><div class="doctor-avatar">♙</div><div><h3>Dr. Allyssa Grace, DMD</h3><p class="muted">General &amp; Restorative Dentistry</p><p>12 years of experience in tooth-colored fillings, emergency dental care, and gentle deep cleanings.</p></div></article></div></section>
<section class="section"><div class="container"><div class="cta"><div><h2>Ready to make your next dental visit easier?</h2><p>Book your appointment and spend less time waiting.</p></div><a class="button" href="#/login?audience=patient">Get started <span>→</span></a></div></div></section>`}
function loginPage(params){
  const audience=params.get("audience");
  let chosen=audience==="patient"?"patient":audience==="staff"?"admin":"";
  return `<section class="auth-page"><div class="auth-card">${logo()}<h1>Demo login</h1><p>Create a patient account or sign in as Admin.</p>
  <div class="role-list" style="margin-bottom:16px">
    <button type="button" class="role-option ${chosen==="patient"?"selected":""}" data-auth="patient"><span class="role-icon">♙</span><span><strong>Patient</strong><small>Create an account or sign in to book visits.</small></span></button>
    <button type="button" class="role-option ${chosen==="admin"?"selected":""}" data-auth="admin"><span class="role-icon">⬡</span><span><strong>Admin</strong><small>Sign in with the clinic administrator account.</small></span></button>
  </div>
  <div id="auth-patient" style="display:${chosen==="admin"?"none":"block"}">
    <div class="tabs" style="display:flex;gap:8px;margin-bottom:14px">
      <button type="button" class="button button-outline tab-btn selected" data-tab="signup" style="flex:1">Create account</button>
      <button type="button" class="button button-outline tab-btn" data-tab="signin" style="flex:1">Sign in</button>
    </div>
    <form id="patient-signup">
      <div class="form-grid" style="grid-template-columns:1fr">
        <div class="field"><label for="su-name">Full name</label><input id="su-name" required placeholder="Maria Santos"></div>
        <div class="field"><label for="su-email">Email</label><input id="su-email" type="email" required placeholder="name@example.com"></div>
        <div class="field"><label for="su-pid">Patient ID (optional)</label><input id="su-pid" placeholder="SC-98214"></div>
        <div class="field"><label for="su-pass">Password</label><input id="su-pass" type="password" required minlength="4" placeholder="Create a password"></div>
      </div>
      <p class="error" id="signup-error" aria-live="polite"></p>
      <button class="button button-primary full" type="submit">Create account <span>→</span></button>
    </form>
    <form id="patient-signin" hidden>
      <div class="form-grid" style="grid-template-columns:1fr">
        <div class="field"><label for="si-email">Email</label><input id="si-email" type="email" required placeholder="name@example.com"></div>
        <div class="field"><label for="si-pass">Password</label><input id="si-pass" type="password" required placeholder="Your password"></div>
      </div>
      <p class="error" id="signin-error" aria-live="polite"></p>
      <button class="button button-primary full" type="submit">Sign in <span>→</span></button>
    </form>
  </div>
  <div id="auth-admin" style="display:${chosen==="patient"?"none":"block"}">
    <form id="admin-login">
      <div class="form-grid" style="grid-template-columns:1fr">
        <div class="field"><label for="ad-user">Username</label><input id="ad-user" required placeholder="Admin" autocomplete="username"></div>
        <div class="field"><label for="ad-pass">Password</label><input id="ad-pass" type="password" required placeholder="Password" autocomplete="current-password"></div>
      </div>
      <p class="error" id="admin-error" aria-live="polite"></p>
      <button class="button button-primary full" type="submit">Sign in as Admin <span>→</span></button>
      <p style="text-align:center;margin-top:12px;color:var(--muted);font-size:12px">Default demo credentials: <strong>Admin</strong> / <strong>Admin123</strong></p>
    </form>
  </div>
  <p style="text-align:center;margin-top:18px"><a class="button-link" href="#/">← Back to home</a></p></div></section>`;
}
function routeDetails(path){const map={
 "/patient/book":["Book an Appointment","Clinical Appointments & Scheduling","Choose your treatment, preferred dentist, and convenient time slot.","Booking steps are next","The 4-step booking flow (service, dentist, date & time, review) will appear here. No online payment is required — settle over-the-counter after your visit."],
 "/patient/appointments":["My Appointments","","View, reschedule, or cancel your scheduled visits, and browse past dental appointment records.","No appointments to show yet","When you book a visit, upcoming and past appointments will be listed here with search, year filters, and pagination."],
 "/admin":["Throughput & Chair Capacity Intelligence","Executive Ops Cockpit","Analytics for no-shows, appointments by service, and daily ledger export.","Analytics coming next","Charts will replace autoclave, bur inventory, and financial ledger panels with no-show analytics and appointments-by-service. Export Daily Ledger as CSV."],
 "/admin/triage":["Live Queue & Triage","","Priority board and operatory telemetry.","Triage board coming next","Waiting patients, pain-level flags, and chair assignments will appear on this page."],
 "/admin/schedule":["Operatory Schedule","","Chair occupancy across clinical wings.","Schedule map coming next","A simple operatory schedule will be added here for the clinic practice director."],
 "/admin/workspace":["Chairside Clinical Workspace","","Chair-side tools for the clinical operating system.","Workspace coming later","This destination matches the admin sidebar in the designs. Patient profile create and update stay clerk-only."]
};return map[path]||map["/patient/book"]}
function dashboard(path){
 const role=path.split("/")[1]||"patient";
 const session=JSON.parse(localStorage.getItem("smartcare-session")||"null")||users[role]||users.patient;
 const user=role==="patient"?{...users.patient,...session}:users[role];
 const details=routeDetails(path);
 const active=path==="/patient" ? "/patient/book":path;
 return `<section class="dashboard"><aside class="sidebar">${logo(role==="patient"?"Dental Clinic Portal":"Practice Director")}<div class="side-label">${role==="admin"?"Clinical Navigation":"Workspace"}</div><nav class="side-nav">${(navs[role]||navs.patient).map(n=>`<a href="#${n[0]}" class="${active===n[0]?"active":""}"><span>${n[1]}</span>${n[2]}${n[3]?`<span class="nav-count">${n[3]}</span>`:""}</a>`).join("")}</nav><div class="side-bottom"><div style="padding:10px 12px;color:var(--muted);font-size:12px">${user.name||user.email||"Guest"}${user.pid?`<br><small>PID: #${user.pid}</small>`:""}</div><div class="side-nav"><a href="#/patient/help"><span>?</span>Help &amp; Support</a><button id="logout"><span>↪</span>Log Out</button></div></div></aside><div class="dashboard-main"><div class="dash-top"><div>${details[1]?`<div class="eyebrow">${details[1]}</div>`:""}<h1>${details[0]}</h1><p>${details[2]}</p></div><span class="tag">Demo workspace</span></div><div class="dashboard-content">${path==="/patient/book"?bookingForm():path==="/patient/appointments"?renderAppointments(user):`<div class="empty-state"><div class="empty-icon">✧</div><h2>${details[3]}</h2><p>${details[4]}</p>${role==="patient"?`<a class="button button-primary" style="margin-top:20px" href="#/patient/book">Book an appointment</a>`:""}</div>`}</div></div></section>`
}
function bookingForm(){return `<section class="panel"><h2>Appointment details</h2><p style="color:var(--muted)">Choose a service and preferred time. This static demo stores your request in this browser only.</p><form id="booking-form"><div class="form-grid"><div class="field"><label for="service">Dental service</label><select id="service" required><option value="">Choose a service</option><option>Oral Prophylaxis & Cleaning — ₱1,500</option><option>Dental Restoration — ₱1,800 per tooth</option><option>Tooth Extraction — ₱2,000+</option><option>Orthodontics Consultation — ₱1,200</option></select></div><div class="field"><label for="dentist">Preferred dentist</label><select id="dentist" required><option value="">Choose a dentist</option><option>Dr. Allyssa Grace, DMD</option><option>First available dentist</option></select></div><div class="field"><label for="date">Preferred date</label><input id="date" type="date" required></div><div class="field"><label for="time">Preferred time</label><select id="time" required><option value="">Choose a time</option><option>09:00 AM</option><option>10:00 AM</option><option>11:00 AM</option><option>01:00 PM</option><option>02:00 PM</option><option>03:00 PM</option></select></div><div class="field" style="grid-column:1/-1"><label for="notes">Notes (optional)</label><textarea id="notes" placeholder="Tell us anything the clinic should know"></textarea></div></div><div class="form-actions"><button type="reset" class="button button-outline">Clear</button><button type="submit" class="button button-primary">Review appointment</button></div><p id="booking-message" class="notice" hidden></p></form></section>`}
function renderAppointments(user){
 const email = user.email || "";
 const allBookings = JSON.parse(localStorage.getItem("smartcare-bookings") || "{}");
 const bookings = allBookings[email] || [];
 if (bookings.length === 0) {
   return `<div class="empty-state"><div class="empty-icon">▤</div><h2>No appointments to show yet</h2><p>When you book a visit, upcoming and past appointments will be listed here with search, year filters, and pagination.</p><a class="button button-primary" style="margin-top:20px" href="#/patient/book">Book an appointment</a></div>`;
 }
 const rows = bookings.map((b, i) => `
   <div class="panel" style="margin-top:14px;padding:20px;display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap">
     <div style="min-width:220px">
       <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px"><span class="tag" style="margin:0">${b.status || "Pending"}</span></div>
       <h3 style="font-size:16px;margin:0">${b.service}</h3>
       <p style="color:var(--muted);margin-top:6px">${b.dentist}</p>
       ${b.notes ? `<p style="color:var(--muted);margin-top:6px;font-size:13px">Note: ${b.notes}</p>` : ""}
     </div>
     <div style="text-align:right;min-width:150px">
       <div style="font-weight:750;color:var(--heading)">${b.date}</div>
       <div style="color:var(--primary);font-weight:700">${b.time}</div>
       <button type="button" class="button button-outline button-small" style="margin-top:10px" data-cancel-index="${i}">Cancel</button>
     </div>
   </div>`).join("");
 return `<section class="panel"><h2>Upcoming appointments</h2><p style="color:var(--muted)">Your scheduled visits with SmartCare.</p>${rows}</section>`;
}
function render(){let hash=location.hash||"#/";let raw=hash.slice(1);let [path,query=""]=raw.split("?");path=path||"/";const params=new URLSearchParams(query);document.querySelector(".site-header").style.display="";document.querySelector(".site-footer").style.display="";if(path==="/"){view.innerHTML=landing()}else if(path==="/login"){view.innerHTML=loginPage(params)}else if(path==="/patient"||path.startsWith("/patient/")||path==="/admin"||path.startsWith("/admin/")){const role=path.split("/")[1];const session=JSON.parse(localStorage.getItem("smartcare-session")||"null");if(!session||session.role!==role){location.hash="#/login?audience="+(role==="patient"?"patient":"staff");return}view.innerHTML=dashboard(path==="/patient"?"/patient/book":path)}else{view.innerHTML=`<section class="auth-page"><div class="auth-card">${logo()}<h1>Page not found</h1><p>This demo page is not available.</p><a class="button button-primary full" href="#/">Back to home</a></div></section>`}
 document.querySelector(".desktop-nav").style.display=path==="/"?"":"none";
 const menu=document.getElementById("menu-toggle");menu.style.display=path==="/"?"":"none";window.scrollTo(0,0);bindForms();}
function bindForms(){
  document.querySelectorAll("[data-auth]").forEach(btn=>btn.addEventListener("click",()=>{
    document.querySelectorAll("[data-auth]").forEach(b=>b.classList.remove("selected"));
    btn.classList.add("selected");
    const isPatient=btn.dataset.auth==="patient";
    document.getElementById("auth-patient").style.display=isPatient?"block":"none";
    document.getElementById("auth-admin").style.display=isPatient?"none":"block";
  }));

  document.querySelectorAll(".tab-btn").forEach(btn=>btn.addEventListener("click",()=>{
    document.querySelectorAll(".tab-btn").forEach(b=>b.classList.remove("selected"));
    btn.classList.add("selected");
    const signup=btn.dataset.tab==="signup";
    document.getElementById("patient-signup").hidden=!signup;
    document.getElementById("patient-signin").hidden=signup;
  }));

  const signup=document.getElementById("patient-signup");
  if(signup)signup.addEventListener("submit",e=>{
    e.preventDefault();
    const email=document.getElementById("su-email").value.trim().toLowerCase();
    const accounts=JSON.parse(localStorage.getItem("smartcare-patients")||"{}");
    if(accounts[email]){document.getElementById("signup-error").textContent="An account with this email already exists.";return}
    const profile={
      role:"patient",
      name:document.getElementById("su-name").value.trim(),
      email,
      pid:document.getElementById("su-pid").value.trim()||("SC-"+Math.floor(10000+Math.random()*89999)),
      password:document.getElementById("su-pass").value,
      home:"/patient/book"
    };
    accounts[email]=profile;
    localStorage.setItem("smartcare-patients",JSON.stringify(accounts));
    localStorage.setItem("smartcare-session",JSON.stringify(profile));
    location.hash="#/patient/book";
  });

  const signin=document.getElementById("patient-signin");
  if(signin)signin.addEventListener("submit",e=>{
    e.preventDefault();
    const email=document.getElementById("si-email").value.trim().toLowerCase();
    const pass=document.getElementById("si-pass").value;
    const accounts=JSON.parse(localStorage.getItem("smartcare-patients")||"{}");
    const account=accounts[email];
    if(!account||account.password!==pass){document.getElementById("signin-error").textContent="Invalid email or password.";return}
    localStorage.setItem("smartcare-session",JSON.stringify(account));
    location.hash="#/patient/book";
  });

  const adminLogin=document.getElementById("admin-login");
  if(adminLogin)adminLogin.addEventListener("submit",e=>{
    e.preventDefault();
    const u=document.getElementById("ad-user").value.trim();
    const p=document.getElementById("ad-pass").value;
    if(u!==users.admin.username||p!==users.admin.password){document.getElementById("admin-error").textContent="Invalid username or password.";return}
    localStorage.setItem("smartcare-session",JSON.stringify({role:"admin",...users.admin}));
    location.hash="#/admin";
  });

  const logout=document.getElementById("logout");
  if(logout)logout.addEventListener("click",()=>{localStorage.removeItem("smartcare-session");location.hash="#/";});

  const booking=document.getElementById("booking-form");
  if(booking){const date=document.getElementById("date");date.min=new Date().toISOString().slice(0,10);booking.addEventListener("submit",e=>{e.preventDefault();
    const session=JSON.parse(localStorage.getItem("smartcare-session")||"null");
    const email=session?.email||"guest";
    const data={
      service:document.getElementById("service").value,
      dentist:document.getElementById("dentist").value,
      date:date.value,
      time:document.getElementById("time").value,
      notes:document.getElementById("notes").value,
      status:"Pending",
      createdAt:new Date().toISOString()
    };
    const allBookings=JSON.parse(localStorage.getItem("smartcare-bookings")||"{}");
    if(!allBookings[email])allBookings[email]=[];
    allBookings[email].push(data);
    localStorage.setItem("smartcare-bookings",JSON.stringify(allBookings));
    const msg=document.getElementById("booking-message");
    msg.hidden=false;
    msg.textContent=`Appointment request saved for ${data.date} at ${data.time}. Check "My Appointments" to view it.`;
    booking.reset();
  });}

  // Cancel appointment handler
  document.querySelectorAll("[data-cancel-index]").forEach(btn=>btn.addEventListener("click",()=>{
    const idx=parseInt(btn.dataset.cancelIndex,10);
    const session=JSON.parse(localStorage.getItem("smartcare-session")||"null");
    const email=session?.email||"guest";
    const allBookings=JSON.parse(localStorage.getItem("smartcare-bookings")||"{}");
    const list=allBookings[email]||[];
    list.splice(idx,1);
    allBookings[email]=list;
    localStorage.setItem("smartcare-bookings",JSON.stringify(allBookings));
    render();
  }));
}
document.getElementById("menu-toggle").addEventListener("click",()=>{const nav=document.querySelector(".desktop-nav");const shown=nav.style.display==="flex";nav.style.display=shown?"none":"flex";nav.style.position=shown?"":"absolute";nav.style.top=shown?"":"72px";nav.style.right=shown?"":"0";nav.style.left=shown?"":"0";nav.style.padding=shown?"":"20px";nav.style.background=shown?"":"white";nav.style.flexDirection=shown?"":"column";nav.style.alignItems=shown?"":"stretch";nav.style.borderBottom=shown?"":"1px solid var(--divider)";});
window.addEventListener("hashchange",render);
render();