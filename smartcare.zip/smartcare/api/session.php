<?php
require __DIR__ . '/db.php';
echo json_encode(['ok'=>true,'user'=>$_SESSION['user'] ?? null]);