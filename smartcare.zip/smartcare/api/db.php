<?php
session_start();
header('Content-Type: application/json');

$DB_HOST = '127.0.0.1';
$DB_USER = 'root';
$DB_PASS = '';           // XAMPP default
$DB_NAME = 'smartcare';

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'DB connection failed: ' . $conn->connect_error]);
    exit;
}
$conn->set_charset('utf8mb4');

function read_json() {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}