<?php
require __DIR__ . '/db.php';
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    http_response_code(401); exit('Admin only');
}
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=smartcare-ledger-' . date('Y-m-d') . '.csv');
$out = fopen('php://output', 'w');
fputcsv($out, ['Patient Email','Patient Name','PID','Service','Dentist','Date','Time','Status','Notes','Created At']);
$res = $conn->query(
  'SELECT p.email, p.name, p.pid, a.service, a.dentist,
          DATE_FORMAT(a.appt_date,"%Y-%m-%d") AS d,
          a.appt_time AS t, a.status, a.notes, a.created_at
   FROM appointments a
   JOIN patients p ON p.id = a.patient_id
   ORDER BY a.created_at DESC'
);
while ($r = $res->fetch_assoc()) fputcsv($out, $r);
fclose($out);