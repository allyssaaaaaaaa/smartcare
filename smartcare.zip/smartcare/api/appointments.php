<?php
require __DIR__ . '/db.php';
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'patient') {
    http_response_code(401); echo json_encode(['ok'=>false,'error'=>'Not signed in']); exit;
}
$uid = (int)$_SESSION['user']['id'];
$stmt = $conn->prepare(
  'SELECT id, service, dentist,
          DATE_FORMAT(appt_date, "%Y-%m-%d") AS date,
          appt_time AS time,
          notes, status, created_at
   FROM appointments WHERE patient_id = ?
   ORDER BY appt_date DESC, appt_time DESC'
);
$stmt->bind_param('i', $uid);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
echo json_encode(['ok'=>true,'appointments'=>$rows]);