<?php
require __DIR__ . '/db.php';
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    http_response_code(401); echo json_encode(['ok'=>false,'error'=>'Admin only']); exit;
}
$total = (int)$conn->query('SELECT COUNT(*) c FROM appointments')->fetch_assoc()['c'];
$uniq  = (int)$conn->query('SELECT COUNT(DISTINCT patient_id) c FROM appointments')->fetch_assoc()['c'];

$rows = $conn->query('SELECT service, COUNT(*) c FROM appointments GROUP BY service ORDER BY c DESC')->fetch_all(MYSQLI_ASSOC);
$services = [];
foreach ($rows as $r) {
    $name = trim(explode('—', $r['service'])[0]);
    $services[$name] = (int)$r['c'];
}

echo json_encode(['ok'=>true,'total'=>$total,'uniquePatients'=>$uniq,'services'=>$services]);