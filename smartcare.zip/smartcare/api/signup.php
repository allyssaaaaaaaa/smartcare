<?php
require __DIR__ . '/db.php';
$in = read_json();
$name  = trim($in['name']  ?? '');
$email = strtolower(trim($in['email'] ?? ''));
$pid   = trim($in['pid']   ?? '');
$pass  = $in['password']   ?? '';

if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 4) {
    echo json_encode(['ok' => false, 'error' => 'Please fill in all fields.']); exit;
}
if ($pid === '') $pid = 'SC-' . random_int(10000, 99999);

$stmt = $conn->prepare('SELECT id FROM patients WHERE email = ? OR pid = ?');
$stmt->bind_param('ss', $email, $pid);
$stmt->execute();
if ($stmt->get_result()->fetch_assoc()) {
    echo json_encode(['ok' => false, 'error' => 'An account with this email or PID already exists.']); exit;
}

$hash = password_hash($pass, PASSWORD_DEFAULT);
$stmt = $conn->prepare('INSERT INTO patients (name,email,pid,password_hash) VALUES (?,?,?,?)');
$stmt->bind_param('ssss', $name, $email, $pid, $hash);
$stmt->execute();

$id = $stmt->insert_id;
$_SESSION['user'] = ['role'=>'patient','id'=>$id,'name'=>$name,'email'=>$email,'pid'=>$pid];

echo json_encode(['ok'=>true,'user'=>$_SESSION['user']]);