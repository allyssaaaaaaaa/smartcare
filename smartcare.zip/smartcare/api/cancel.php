<?php
require __DIR__ . '/db.php';
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'patient') {
    http_response_code(401); echo json_encode(['ok'=>false,'error'=>'Not signed in']); exit;
}
$in = read_json();
$id = (int)($in['id'] ?? 0);
$uid = (int)$_SESSION['user']['id'];
$stmt = $conn->prepare('DELETE FROM appointments WHERE id = ? AND patient_id = ?');
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();
echo json_encode(['ok'=>true]);