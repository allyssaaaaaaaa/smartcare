<?php
require __DIR__ . '/db.php';
$in = read_json();
if (($in['username'] ?? '') === 'Admin' && ($in['password'] ?? '') === 'Admin123') {
    $_SESSION['user'] = ['role'=>'admin','name'=>'Admin','title'=>'Clinic Practice Director'];
    echo json_encode(['ok'=>true,'user'=>$_SESSION['user']]);
} else {
    echo json_encode(['ok'=>false,'error'=>'Invalid username or password.']);
}