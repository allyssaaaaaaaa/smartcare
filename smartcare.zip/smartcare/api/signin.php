<?php
require __DIR__ . '/db.php';
$in = read_json();
$email = strtolower(trim($in['email'] ?? ''));
$pass  = $in['password'] ?? '';

$stmt = $conn->prepare('SELECT id,name,email,pid,password_hash FROM patients WHERE email = ?');
$stmt->bind_param('s', $email);
$stmt->execute();
$u = $stmt->get_result()->fetch_assoc();

if (!$u || !password_verify($pass, $u['password_hash'])) {
    echo json_encode(['ok'=>false,'error'=>'Invalid email or password.']); exit;
}
unset($u['password_hash']);
$u['role'] = 'patient';
$_SESSION['user'] = $u;
echo json_encode(['ok'=>true,'user'=>$u]);