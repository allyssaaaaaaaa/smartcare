<?php
require __DIR__ . '/db.php';
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'patient') {
    http_response_code(401); echo json_encode(['ok'=>false,'error'=>'Not signed in']); exit;
}
$in = read_json();
$uid = (int)$_SESSION['user']['id'];

$service = trim($in['service'] ?? '');
$dentist = trim($in['dentist'] ?? '');
$date    = trim($in['date']    ?? '');
$timeIn  = trim($in['time']    ?? '');
$notes   = trim($in['notes']   ?? '');

if ($service === '' || $dentist === '' || $date === '' || $timeIn === '') {
    echo json_encode(['ok'=>false,'error'=>'Missing required fields.']); exit;
}

// Convert "09:00 AM" → "09:00:00"
$time24 = date('H:i:s', strtotime($timeIn));

$stmt = $conn->prepare('INSERT INTO appointments (patient_id,service,dentist,appt_date,appt_time,notes) VALUES (?,?,?,?,?,?)');
$stmt->bind_param('isssss', $uid, $service, $dentist, $date, $time24, $notes);
if (!$stmt->execute()) { echo json_encode(['ok'=>false,'error'=>$conn->error]); exit; }
echo json_encode(['ok'=>true,'id'=>$stmt->insert_id]);