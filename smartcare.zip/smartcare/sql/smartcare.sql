CREATE DATABASE IF NOT EXISTS smartcare
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smartcare;

CREATE TABLE IF NOT EXISTS patients (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(120) NOT NULL,
  email         VARCHAR(160) NOT NULL UNIQUE,
  pid           VARCHAR(20)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS appointments (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  patient_id  INT NOT NULL,
  service     VARCHAR(160) NOT NULL,
  dentist     VARCHAR(120) NOT NULL,
  appt_date   DATE NOT NULL,
  appt_time   TIME NOT NULL,
  notes       TEXT,
  status      ENUM('Pending','Confirmed','Completed','Cancelled') DEFAULT 'Pending',
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
);

-- Optional demo patient (password: demo1234)
-- INSERT INTO patients (name,email,pid,password_hash) VALUES
-- ('Maria Santos','maria@example.com','SC-98214',
--  '$2y$10$eImiTXuWVxfM37uY4JANjQ==replace_with_your_own_hash');